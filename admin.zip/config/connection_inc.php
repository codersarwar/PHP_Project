<?php
//session_start();
$found =mysqli_connect("localhost","root","","e_commerce");
if(mysqli_connect_error()){
    echo "connection is failed";
    exit();
}
?>