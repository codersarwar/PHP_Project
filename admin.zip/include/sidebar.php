<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<ul>
<li class="menu-title">
</li>
<li class="active">
<a href="index.php"><i class="fa-solid fa-house-chimney"></i> <span>Dashboard</span></a>
</li>
<li class="">
<a href="#"><i class="fa-solid fa-cart-arrow-down"></i> <span>Order Managment</span></a>
</li>
<li class="">
<a href="usermanagement.php"><i class="fa-solid fa-users"></i> <span>User Managment</span></a>
</li>

<li class="">
<a href="catagory.php"><i class="fa-solid fa-align-justify"></i> <span>Catagory Managment</span></a>
</li>

<li class="">
<a href="cuponmanagement.php"><i class="fa-solid fa-tags"></i> <span>Cupon Managment</span></a>
</li>

</ul>

</div>
</div>
</div>